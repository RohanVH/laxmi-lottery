-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2022 at 06:57 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laxmi-lottery`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id`, `username`, `password`) VALUES
(1, 'admin', 'pass'),
(2, 'Rohan', 'rohan');

-- --------------------------------------------------------

--
-- Table structure for table `randdata`
--

CREATE TABLE `randdata` (
  `id` int(30) NOT NULL,
  `AA` varchar(10) NOT NULL,
  `BB` varchar(11) NOT NULL,
  `CC` varchar(11) NOT NULL,
  `a` varchar(11) NOT NULL,
  `b` varchar(11) NOT NULL,
  `c` varchar(11) NOT NULL,
  `time` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `randdata`
--

INSERT INTO `randdata` (`id`, `AA`, `BB`, `CC`, `a`, `b`, `c`, `time`, `status`) VALUES
(1, '73', '04', '50', '7', '0', '5', '', ''),
(2, '92', '68', '54', '9', '6', '5', '', ''),
(3, '64', '96', '34', '6', '9', '3', '', ''),
(4, '95', '12', '28', '9', '1', '2', '', ''),
(5, '96', '21', '06', '9', '2', '0', '', ''),
(6, '15', '85', '07', '1', '8', '0', '', ''),
(7, '89', '70', '71', '8', '7', '7', '', ''),
(8, '65', '04', '04', '6', '0', '0', '', ''),
(9, '71', '83', '76', '7', '8', '7', '', ''),
(10, '94', '27', '34', '9', '2', '3', '', ''),
(11, '64', '48', '95', '6', '4', '9', '', ''),
(12, '45', '06', '74', '4', '0', '7', '', ''),
(13, '80', '25', '45', '8', '2', '4', '', ''),
(14, '08', '34', '89', '0', '3', '8', '', ''),
(15, '15', '08', '13', '1', '0', '1', '', ''),
(16, '56', '25', '12', '5', '2', '1', '', ''),
(17, '98', '96', '71', '9', '9', '7', '', ''),
(18, '81', '58', '18', '8', '5', '1', '', ''),
(19, '03', '85', '48', '0', '8', '4', '', ''),
(20, '50', '19', '71', '5', '1', '7', '', ''),
(21, '27', '24', '74', '2', '2', '7', '', ''),
(22, '15', '45', '98', '1', '4', '9', '', ''),
(23, '71', '39', '02', '7', '3', '0', '', ''),
(24, '81', '58', '92', '8', '5', '9', '', ''),
(25, '52', '72', '13', '5', '7', '1', '', ''),
(26, '40', '01', '16', '4', '0', '1', '', ''),
(27, '60', '80', '56', '6', '8', '5', '', ''),
(28, '27', '59', '49', '2', '5', '4', '', ''),
(29, '57', '29', '29', '5', '2', '2', '', ''),
(30, '17', '49', '28', '1', '4', '2', '', ''),
(31, '83', '71', '93', '8', '7', '9', '', ''),
(32, '41', '10', '62', '4', '1', '6', '', ''),
(33, '20', '65', '27', '2', '6', '2', '', ''),
(34, '24', '19', '86', '2', '1', '8', '', ''),
(35, '78', '25', '64', '7', '2', '6', '', ''),
(36, '80', '81', '04', '8', '8', '0', '', ''),
(37, '60', '75', '62', '6', '7', '6', '', ''),
(38, '38', '76', '48', '3', '7', '4', '', ''),
(39, '39', '63', '30', '3', '6', '3', '', ''),
(40, '64', '53', '42', '6', '5', '4', '', ''),
(41, '92', '74', '65', '9', '7', '6', '', ''),
(42, '59', '18', '05', '5', '1', '0', '', ''),
(43, '45', '27', '43', '4', '2', '4', '', ''),
(44, '62', '14', '25', '6', '1', '2', '', ''),
(45, '30', '15', '68', '3', '1', '6', '', ''),
(46, '46', '34', '17', '4', '3', '1', '', ''),
(47, '91', '94', '08', '9', '9', '0', '', ''),
(48, '89', '97', '53', '8', '9', '5', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `randdata`
--
ALTER TABLE `randdata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `randdata`
--
ALTER TABLE `randdata`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

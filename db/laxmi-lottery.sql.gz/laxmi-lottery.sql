-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2022 at 10:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laxmi-lottery`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth`
--

CREATE TABLE `auth` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth`
--

INSERT INTO `auth` (`id`, `username`, `password`) VALUES
(2, 'admin', 'password'),
(3, 'rohan', 'rohan');

-- --------------------------------------------------------

--
-- Table structure for table `randdata`
--

CREATE TABLE `randdata` (
  `id` int(30) NOT NULL,
  `AA` varchar(10) NOT NULL,
  `BB` varchar(11) NOT NULL,
  `CC` varchar(11) NOT NULL,
  `a` varchar(11) NOT NULL,
  `b` varchar(11) NOT NULL,
  `c` varchar(11) NOT NULL,
  `time` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `randdata`
--

INSERT INTO `randdata` (`id`, `AA`, `BB`, `CC`, `a`, `b`, `c`, `time`, `status`) VALUES
(1, '52', '82', '54', '5', '8', '5', '', ''),
(2, '27', '72', '68', '2', '7', '6', '', ''),
(3, '59', '51', '03', '5', '5', '0', '', ''),
(4, '12', '30', '14', '1', '3', '1', '', ''),
(5, '71', '79', '45', '7', '7', '4', '', ''),
(6, '31', '79', '43', '3', '7', '4', '', ''),
(7, '61', '10', '39', '6', '1', '3', '', ''),
(8, '51', '59', '28', '5', '5', '2', '', ''),
(9, '03', '48', '89', '0', '4', '8', '', ''),
(10, '94', '85', '18', '9', '8', '1', '', ''),
(11, '83', '37', '85', '8', '3', '8', '', ''),
(12, '13', '95', '13', '1', '9', '1', '', ''),
(13, '25', '48', '56', '2', '4', '5', '', ''),
(14, '23', '49', '05', '2', '4', '0', '', ''),
(15, '01', '94', '76', '0', '9', '7', '', ''),
(16, '27', '76', '69', '2', '7', '6', '', ''),
(17, '73', '74', '12', '7', '7', '1', '', ''),
(18, '13', '23', '27', '1', '2', '2', '', ''),
(19, '62', '70', '32', '6', '7', '3', '', ''),
(20, '53', '71', '85', '5', '7', '8', '', ''),
(21, '39', '82', '46', '3', '8', '4', '', ''),
(22, '80', '13', '74', '8', '1', '7', '', ''),
(23, '52', '10', '64', '5', '1', '6', '', ''),
(24, '60', '94', '85', '6', '9', '8', '', ''),
(25, '09', '50', '83', '0', '5', '8', '', ''),
(26, '87', '81', '65', '8', '8', '6', '', ''),
(27, '70', '31', '37', '7', '3', '3', '', ''),
(28, '19', '34', '89', '1', '3', '8', '', ''),
(29, '47', '94', '98', '4', '9', '9', '', ''),
(30, '30', '53', '62', '3', '5', '6', '', ''),
(31, '67', '85', '60', '6', '8', '6', '', ''),
(32, '15', '47', '51', '1', '4', '5', '', ''),
(33, '03', '41', '19', '0', '4', '1', '', ''),
(34, '46', '65', '50', '4', '6', '5', '', ''),
(35, '98', '51', '37', '9', '5', '3', '', ''),
(36, '82', '04', '52', '8', '0', '5', '', ''),
(37, '96', '32', '27', '9', '3', '2', '', ''),
(38, '80', '07', '30', '8', '0', '3', '', ''),
(39, '37', '93', '45', '3', '9', '4', '', ''),
(40, '26', '50', '61', '2', '5', '6', '', ''),
(41, '82', '89', '82', '8', '8', '8', '', ''),
(42, '07', '71', '27', '0', '7', '2', '', ''),
(43, '51', '64', '53', '5', '6', '5', '', ''),
(44, '91', '05', '83', '9', '0', '8', '', ''),
(45, '10', '21', '62', '1', '2', '6', '', ''),
(46, '92', '42', '21', '9', '4', '2', '', ''),
(47, '60', '25', '87', '6', '2', '8', '', ''),
(48, '51', '53', '48', '5', '5', '4', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth`
--
ALTER TABLE `auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `randdata`
--
ALTER TABLE `randdata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth`
--
ALTER TABLE `auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `randdata`
--
ALTER TABLE `randdata`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
